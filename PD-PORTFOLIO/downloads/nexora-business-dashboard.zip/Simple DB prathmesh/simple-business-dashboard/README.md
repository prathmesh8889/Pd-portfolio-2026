# Simple Business Dashboard

A clean, professional and fully responsive business dashboard built with HTML5, CSS3 and Vanilla JavaScript. The project uses realistic dummy data stored in JavaScript arrays and objects—no backend or database is required.

## Features

- Eight separate working pages with shared responsive navigation
- Dashboard, Customers, Leads, Projects, Tasks, Insights, Reports and Settings
- Mobile hamburger menu with overlay and Escape-key support
- Dynamic summary cards generated from JavaScript
- Monthly performance chart
- Recent activities generated from JavaScript
- Recent projects table generated from JavaScript
- Live project search by project or client name
- Project status filter
- Customer search and account-status filter
- Customer detail view, inline status updates and complete account editing
- Interactive lead pipeline with stage movement
- Interactive task completion and focus score
- Working Add Customer and Add Task forms with browser persistence
- Working Add Project and Add Lead forms with browser persistence
- Interactive monthly performance periods and live chart updates
- Working recent-project search, status filter and view-all navigation
- Working project action menus with edit, delete confirmation and persistence
- Custom report builder with generated downloads and saved history
- Actionable referral insight review workflow
- Searchable and filterable complete activity-history page
- Touch-friendly profile dropdown with profile details and account actions
- Working notification panel with mark-all-read behavior
- Report file downloads and schedule toggle
- Excel-ready CSV exports with structured customer, project, lead and summary data
- Functional General, Notifications, Security and Team settings tabs
- Advanced n8n configuration with API connection testing, webhook setup and event mapping
- Team invitations, role updates, password validation and browser persistence
- Responsive layouts for desktop, laptop, tablet and mobile
- Semantic, accessible HTML with visible keyboard focus
- Separate HTML, CSS and JavaScript source files

## Project Structure

```text
.
├── index.html       # Netlify entry page
├── dashboard.html   # Semantic page structure
├── dashboard.css    # Layout, components and responsive styles
├── dashboard.js     # Dashboard data and interactions
├── pages.js         # Shared multi-page data, rendering and interactions
├── customers.html
├── leads.html
├── projects.html
├── tasks.html
├── insights.html
├── reports.html
├── settings.html
├── activities.html
└── _redirects       # Netlify routing configuration
```

## How It Works

### HTML

`dashboard.html` contains the semantic structure: sidebar navigation, header, welcome section, performance area, activities panel and projects table. Empty containers such as `#summaryCards`, `#activitiesList` and `#projectsTableBody` are filled by JavaScript.

### CSS

`dashboard.css` uses CSS Grid for the summary cards and main dashboard panels, Flexbox for component alignment, CSS custom properties for consistent design tokens, and media queries at 1100px, 900px, 640px and 390px.

### JavaScript

`dashboard.js` stores dashboard information in the `dashboardData` object. `pages.js` contains data and page-specific render functions for the seven additional pages. Array methods generate cards, tables, pipelines and task lists dynamically.

### Responsive Sidebar

Below 900px the sidebar moves outside the viewport with `transform: translateX(-100%)`. Clicking the hamburger adds the `.open` class, while the overlay, a navigation click or the Escape key closes it.

## Run Locally

Open `index.html` directly in a browser, or serve the project root with any static server.

## Git Commit Plan

Use meaningful commits for each development stage:

```bash
git add .
git commit -m "chore: initialize dashboard project"
git commit -am "feat: add responsive dashboard layout"
git commit -am "feat: render dashboard data dynamically"
git commit -am "feat: add project search and status filter"
git commit -am "docs: update README and deployment guide"
```

## Netlify Deployment

1. Push the repository to GitHub.
2. Sign in to Netlify and select **Add new site → Import an existing project**.
3. Choose GitHub and select this repository.
4. Set the publish directory to the repository root (`.`).
5. Leave the build command empty and deploy.

## Demo Video Script (2–3 minutes)

1. Introduce the project and technologies: HTML5, CSS3 and Vanilla JavaScript.
2. Show the semantic HTML sections and dynamic placeholder containers.
3. Explain how Grid, Flexbox and media queries create the responsive layout.
4. Resize to mobile and demonstrate the hamburger menu and overlay.
5. Open `dashboard.js` and show the `dashboardData` object and render functions.
6. Search for “banking” and show the table updating instantly.
7. Select “Completed” and “On Hold” in the status filter.
8. Show the GitHub commit history, then open the deployed website.

## Testing Checklist

- [x] Dynamic summary cards and project table
- [x] Search by project and client
- [x] Status filtering
- [x] Mobile menu open/close behavior
- [x] Keyboard focus and Escape-key behavior
- [x] Responsive desktop, tablet and mobile layouts
- [x] No browser console errors
