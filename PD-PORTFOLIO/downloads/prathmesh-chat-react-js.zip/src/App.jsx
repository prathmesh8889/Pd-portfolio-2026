import { useMemo, useState } from "react";

const contacts = [
  { id: 1, name: "Aarav Sharma", initials: "AS", color: "#7758f6", status: "Online", preview: "That sounds perfect! See you then.", time: "10:42 AM", unread: 2, online: true },
  { id: 2, name: "Sneha Patil", initials: "SP", color: "#ef6a8a", status: "Online", preview: "Sent a photo", time: "9:18 AM", online: true },
  { id: 3, name: "Rohan Deshmukh", initials: "RD", color: "#25a7a0", status: "Last seen 15 minutes ago", preview: "Can you share the project files?", time: "Yesterday" },
  { id: 4, name: "Priya Kulkarni", initials: "PK", color: "#f09a3e", status: "Last seen yesterday", preview: "Thank you! 😊", time: "Yesterday" },
  { id: 5, name: "Dev Team", initials: "DT", color: "#4376db", status: "5 members", preview: "Kabir: Build completed successfully.", time: "Monday", unread: 5 },
];

const defaultMessages = {
  1: [
    { id: 1, text: "Hi Prathmesh! How is the chat application going?", mine: false, time: "10:35 AM" },
    { id: 2, text: "Hey Aarav! It’s going well. I have completed all the main pages.", mine: true, time: "10:37 AM" },
    { id: 3, text: "That’s great! Are we still meeting at 5 PM?", mine: false, time: "10:39 AM" },
    { id: 4, text: "Yes, absolutely. I will send you the working ZIP.", mine: true, time: "10:41 AM" },
    { id: 5, text: "That sounds perfect! See you then.", mine: false, time: "10:42 AM" },
  ],
  2: [{ id: 1, text: "Hi! I shared the latest design screenshot.", mine: false, time: "9:18 AM" }],
  3: [{ id: 1, text: "Can you share the project files?", mine: false, time: "Yesterday" }],
  4: [{ id: 1, text: "Thank you! 😊", mine: false, time: "Yesterday" }],
  5: [{ id: 1, text: "Build completed successfully.", mine: false, time: "Monday" }],
};

function readSavedMessages() {
  try {
    return JSON.parse(localStorage.getItem("prathmesh-react-messages")) || defaultMessages;
  } catch {
    return defaultMessages;
  }
}

function Avatar({ contact, large = false }) {
  return (
    <div className={`avatar ${large ? "large" : ""}`} style={{ background: contact.color }}>
      {contact.initials}
      {contact.online && <span className="online" />}
    </div>
  );
}

export default function App() {
  const [loggedIn, setLoggedIn] = useState(() => localStorage.getItem("prathmesh-react-session") === "yes");
  const [register, setRegister] = useState(false);
  const [page, setPage] = useState("chats");
  const [activeId, setActiveId] = useState(1);
  const [search, setSearch] = useState("");
  const [draft, setDraft] = useState("");
  const [messages, setMessages] = useState(readSavedMessages);
  const [dark, setDark] = useState(() => localStorage.getItem("prathmesh-react-theme") === "dark");
  const [toast, setToast] = useState("");
  const [mobileChat, setMobileChat] = useState(false);

  const active = contacts.find((item) => item.id === activeId) || contacts[0];
  const filtered = useMemo(
    () => contacts.filter((item) => item.name.toLowerCase().includes(search.toLowerCase())),
    [search],
  );

  function showToast(text) {
    setToast(text);
    setTimeout(() => setToast(""), 2000);
  }

  function login(event) {
    event.preventDefault();
    localStorage.setItem("prathmesh-react-session", "yes");
    setLoggedIn(true);
  }

  function logout() {
    localStorage.removeItem("prathmesh-react-session");
    setLoggedIn(false);
    setPage("chats");
  }

  function toggleTheme() {
    const next = !dark;
    setDark(next);
    localStorage.setItem("prathmesh-react-theme", next ? "dark" : "light");
  }

  function sendMessage(event) {
    event.preventDefault();
    if (!draft.trim()) return;
    const updated = {
      ...messages,
      [activeId]: [
        ...(messages[activeId] || []),
        {
          id: Date.now(),
          text: draft.trim(),
          mine: true,
          time: new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }),
        },
      ],
    };
    setMessages(updated);
    localStorage.setItem("prathmesh-react-messages", JSON.stringify(updated));
    setDraft("");
  }

  if (!loggedIn) {
    return (
      <main className={`auth-page ${dark ? "dark" : ""}`}>
        <button className="theme-button" onClick={toggleTheme} aria-label="Change theme">{dark ? "☀" : "☾"}</button>
        <section className="auth-card">
          <div className="logo">P</div>
          <p className="eyebrow">WELCOME TO</p>
          <h1>Prathmesh Chat</h1>
          <p className="muted">{register ? "Create an account and start connecting." : "Sign in to continue your conversations."}</p>
          <form onSubmit={login}>
            {register && <label>Full name<input required placeholder="Prathmesh Dake" /></label>}
            <label>Email address<input required type="email" placeholder="you@example.com" /></label>
            <label>Password<input required type="password" minLength="6" placeholder="Minimum 6 characters" /></label>
            <button className="primary" type="submit">{register ? "Create account" : "Sign in"}</button>
          </form>
          <button className="link-button" onClick={() => setRegister(!register)}>
            {register ? "Already have an account? Sign in" : "New here? Create an account"}
          </button>
          <Copyright />
        </section>
      </main>
    );
  }

  return (
    <main className={`app ${dark ? "dark" : ""}`}>
      {toast && <div className="toast">{toast}</div>}
      <aside className="nav-rail">
        <div className="logo small">P</div>
        <nav>
          <NavButton icon="▣" label="Chats" active={page === "chats"} onClick={() => setPage("chats")} />
          <NavButton icon="♙" label="Contacts" active={page === "contacts"} onClick={() => setPage("contacts")} />
          <NavButton icon="◎" label="Profile" active={page === "profile"} onClick={() => setPage("profile")} />
          <NavButton icon="⚙" label="Settings" active={page === "settings"} onClick={() => setPage("settings")} />
        </nav>
        <button className="logout" onClick={logout}>↪<span>Log out</span></button>
      </aside>

      {page === "chats" && (
        <section className="chat-layout">
          <aside className={`conversation-list ${mobileChat ? "hide-mobile" : ""}`}>
            <header><div><p className="eyebrow">MESSAGES</p><h1>Chats</h1></div><button className="new-chat" onClick={() => showToast("New conversation ready")}>＋</button></header>
            <Search value={search} onChange={setSearch} placeholder="Search conversations" />
            <div className="contact-scroll">
              {filtered.map((contact) => (
                <button className={`contact ${activeId === contact.id ? "selected" : ""}`} key={contact.id} onClick={() => { setActiveId(contact.id); setMobileChat(true); }}>
                  <Avatar contact={contact} />
                  <span className="contact-copy"><strong>{contact.name}</strong><small>{contact.preview}</small></span>
                  <span className="contact-meta"><small>{contact.time}</small>{contact.unread && <b>{contact.unread}</b>}</span>
                </button>
              ))}
            </div>
            <p className="side-copy">© 2026 Prathmesh Dake</p>
          </aside>

          <section className={`chat-panel ${mobileChat ? "show-mobile" : ""}`}>
            <header className="chat-header">
              <button className="back" onClick={() => setMobileChat(false)}>‹</button>
              <Avatar contact={active} />
              <div><strong>{active.name}</strong><small>{active.status}</small></div>
              <div className="actions">
                <button onClick={() => showToast("Voice call ready")}>☎</button>
                <button onClick={() => showToast("Video call ready")}>▣</button>
                <button onClick={() => showToast("Menu opened")}>•••</button>
              </div>
            </header>
            <div className="messages">
              <span className="date">Today</span>
              {(messages[activeId] || []).map((message) => (
                <div className={`message ${message.mine ? "mine" : ""}`} key={message.id}>
                  <div className="bubble">{message.text}<small>{message.time}{message.mine && " ✓✓"}</small></div>
                </div>
              ))}
            </div>
            <form className="composer" onSubmit={sendMessage}>
              <button type="button" onClick={() => showToast("Attachment picker ready")}>＋</button>
              <input value={draft} onChange={(event) => setDraft(event.target.value)} placeholder={`Message ${active.name.split(" ")[0]}…`} />
              <button type="button" onClick={() => setDraft((value) => value + " 😊")}>☺</button>
              <button className="send" type="submit">➤</button>
            </form>
          </section>
        </section>
      )}

      {page === "contacts" && (
        <Page title="Contacts" eyebrow="YOUR NETWORK" subtitle="Find someone and start a conversation.">
          <Search value={search} onChange={setSearch} placeholder="Search contacts" wide />
          <div className="people-grid">
            {filtered.map((contact) => (
              <article className="person-card" key={contact.id}>
                <Avatar contact={contact} large />
                <h2>{contact.name}</h2><p>{contact.status}</p>
                <button className="primary" onClick={() => { setActiveId(contact.id); setPage("chats"); setMobileChat(true); }}>Message</button>
              </article>
            ))}
          </div>
        </Page>
      )}

      {page === "profile" && (
        <Page title="Profile" eyebrow="YOUR ACCOUNT" subtitle="Keep your personal information up to date." narrow>
          <form className="card" onSubmit={(event) => { event.preventDefault(); showToast("Profile saved successfully"); }}>
            <div className="profile-top"><div className="avatar profile-avatar">PD</div><div><h2>Prathmesh Dake</h2><p>Available</p></div></div>
            <div className="form-grid">
              <label>Full name<input defaultValue="Prathmesh Dake" /></label>
              <label>Email<input type="email" defaultValue="prathmeshdake8889@gmail.com" /></label>
              <label>Phone<input defaultValue="+91 98765 43210" /></label>
              <label>Location<input defaultValue="Maharashtra, India" /></label>
            </div>
            <label>About<textarea defaultValue="Web developer building useful, responsive digital experiences." /></label>
            <button className="primary fit" type="submit">Save changes</button>
          </form>
        </Page>
      )}

      {page === "settings" && (
        <Page title="Settings" eyebrow="PREFERENCES" subtitle="Control your chat experience and privacy." narrow>
          <div className="card">
            <Setting title="Dark appearance" text="Use a darker interface in low light"><button className={`switch ${dark ? "on" : ""}`} onClick={toggleTheme}><span /></button></Setting>
            <Setting title="Message notifications" text="Show alerts for new messages"><button className="switch on" onClick={() => showToast("Notifications updated")}><span /></button></Setting>
            <Setting title="Read receipts" text="Show when you have read a message"><button className="switch on" onClick={() => showToast("Read receipts updated")}><span /></button></Setting>
            <Setting title="Blocked contacts" text="Review people you have blocked"><button className="outline" onClick={() => showToast("No blocked contacts")}>Manage</button></Setting>
            <Setting title="Clear chat history" text="Restore the default demo messages"><button className="danger" onClick={() => { setMessages(defaultMessages); localStorage.removeItem("prathmesh-react-messages"); showToast("Messages restored"); }}>Clear</button></Setting>
          </div>
        </Page>
      )}
    </main>
  );
}

function NavButton({ icon, label, active, onClick }) {
  return <button className={active ? "active" : ""} onClick={onClick} aria-label={label}>{icon}<span>{label}</span></button>;
}

function Search({ value, onChange, placeholder, wide = false }) {
  return <div className={`search ${wide ? "wide" : ""}`}><span>⌕</span><input value={value} onChange={(event) => onChange(event.target.value)} placeholder={placeholder} /></div>;
}

function Page({ title, eyebrow, subtitle, narrow = false, children }) {
  return <section className={`content-page ${narrow ? "narrow" : ""}`}><div className="page-heading"><p className="eyebrow">{eyebrow}</p><h1>{title}</h1><p>{subtitle}</p></div>{children}<Copyright /></section>;
}

function Setting({ title, text, children }) {
  return <div className="setting"><div><strong>{title}</strong><p>{text}</p></div>{children}</div>;
}

function Copyright() {
  return <footer>© 2026 Prathmesh Dake. All rights reserved.</footer>;
}
