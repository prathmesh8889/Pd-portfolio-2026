# Prathmesh Chat — React JS

This project uses standard React JavaScript, HTML, and CSS with Vite.

## Run the project

1. Install Node.js.
2. Extract the ZIP and open the folder in VS Code.
3. Open the VS Code terminal.
4. Run:

```bash
npm install
npm run dev
```

5. Open the local URL shown in the terminal.

## Features

- Sign in and registration screens
- Chats, contacts, profile, and settings pages
- Search and message sending
- Browser-based message and preference storage
- Light and dark themes
- Mobile responsive layout
- Copyright © 2026 Prathmesh Dake

This is a frontend demonstration. Real multi-user chat requires a backend,
authentication service, and real-time database.
